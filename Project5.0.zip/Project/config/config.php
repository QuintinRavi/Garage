<?php

define('DB_HOST', 'project-quintinravi-04c7.aivencloud.com:17556');
define('DB_NAME', 'garage2');
define('DB_USER', 'avnadmin');
define('DB_PASS', 'ie3cjcl77ueuu97b');

