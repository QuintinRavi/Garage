<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css%20en%20java/styling.scss">
    <title>Garage Ertan</title>

</head>
<body>

<div class="topnav">
    <a class="active" href="../index.php">Home</a>
    <a href="info.php">Over ons</a>
    <a href="contact.php"><strong>Contact</strong></a>
    <a href="../login/index.php">login</a>
    <a href="../afspraken/AfspraakRegistration.php">afspraken</a>
</div>
    <iframe class="iframec"
            width="1500"
            height="450"
            frameborder="0" style="border:0"
            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAA6iWSmMjFDFZBpSW2Nh5MFQNAD5eo0MU
    &q=Willem+Buytewechstraat ,Netherlands+RO" allowfullscreen>
    </iframe>
<br>
<h2 class="text5">GARAGEBEDRIJF Ertan</h2>
<br>
    <div class="list1">
        <ul>
            <li><strong>Adres</strong></li>
            <li>Willem Buytewechstraat</li>
            <li>Delfshaven</li>
            <li>Nederland</li>
        </ul>
        <br>
        <div class="list2">
            <ul>
                <li><strong>gegevens</strong></li>
                <li>TEL:010-401020</li>
                <li>Email:info@garageErtan.com</li>
            </ul>
        </div>
        <br>
        <ul>
            <li><strong>als u een vraag heeft kunt u gerust een mailtje sturen of ons bellen.</strong></li>
        </ul>

    </div>


</body>
</html>
