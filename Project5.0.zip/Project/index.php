<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="main/css en java/styling.scss">
    <title>Garage Ertan</title>

</head>
<body>

<div class="topnav">
    <a class="active" href="index.php"><strong>Home</strong></a>
    <a href="main/info.php">over ons</a>
    <a href="main/contact.php">contact</a>
    <a href="login/index.php">login</a>
    <a href="afspraken/AfspraakRegistration.php">afspraken</a>
</div
<br>
<div class="text1">
<p> Garage Ertan is een bedrijf die in Delfshaven is gevestigd. het was een bedrijf dat alleen met famillie leden ging
werken maar inmiddels is het een super groot bedrijf geworden, die samen met schadeverzekeringen werkt zij krijgen via
daar de meeste opdracht. ze hebben ook stagairs in hun bedrijf zitten die leren nog meer over het auto techniek. Garagae Ertan
is een bedrijf die naar zulke stagairs opzoek zijn zij willen mensen hebben die leergierig zijn en goed smaen en evetueel
ook aleen kunnen werken.</p>
</div>
<img class="img4" src="main/image/garage1.jpg" alt="garage1" width="300" height="250">

<a href="main/contact.php" class="button1">contact informatie</a>

<img class="img2" src="main/image/logo2.png" alt="moersleuten" width="100" height="120">
<img class="img1" src="main/image/logo1.png" alt="tandwiel" width="150" height="120">
<img class="img3" src="main/image/logo2.png" alt="moersleuten" width="100" height="120">
<br>
<p class="text2">Bij deze garage bent u bij de juiste adress voor een grote  of kleine beurt.</p>
<p class="text3">De juiste plek voor uw auto om hem APK te laten keuren.</p>
<p class="text4">Bij garage Ertan kunt u terecht voor al uw onderhoud voor uw auto.</p>
<br>
<div class="iframe2">
<iframe class="iframe"
        width="600"
        height="450"
        frameborder="0" style="border:0"
        src="https://www.google.com/maps/embed/v1/place?key=AIzaSyAA6iWSmMjFDFZBpSW2Nh5MFQNAD5eo0MU
    &q=Willem+Buytewechstraat ,Netherlands+RO" allowfullscreen>
</iframe></div>
<br>

</body>
</html>
